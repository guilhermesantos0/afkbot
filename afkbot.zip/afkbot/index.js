const Discord = require('discord.js-selfbot-v11');
const config = require('./config.json');
const colors = require('colors');
const readline = require('readline')
const client = new Discord.Client();

let afk = false

const commands = {
  "afk" : function(){
    if(afk){
      afk = false
      console.log(colors.yellow("[ALERTA]") + " " + colors.red("SISTEMA DE AFK DESLIGADO"))
      client.user.setStatus('dnd')
    }else{
      afk = true
      console.log(colors.yellow("[ALERTA]") + " " + colors.green("SISTEMA DE AFK LIGADO"))
      client.user.setStatus('idle')
    }
  },
  "afkstatus" : function(){
    if(afk){
      console.log(colors.yellow("[ALERTA]") + " " + colors.green("LIGADO"))
    }else{
      console.log(colors.yellow("[ALERTA]") + " " + colors.red("DESLIGADO"))
    }
  },
  "stop": function(){
    process.exit()
  }
}

client.on('ready', () => {
  console.log(colors.green(`Logado com sucesso com ${client.user.tag}`))
  askQuestion("\n> ")
})

client.on('message',async message => {
  if(afk){
    if(message.channel.type=="text"){
      if(message.content.includes(`<@!${client.user.id}>`) || message.content.includes(`<@${client.user.id}>`)){
        if(message.author.id == client.user.id) return
        console.log(`${colors.green(`[${message.guild.name.toUpperCase()}]`)} ${message.author.username} - ${message.content ? message.content : "arquivo"}`)
        message.reply("to off ja respondo :)")
      }
    }else{
      if(message.author.id == client.user.id) return
      console.log(`${colors.red("[DM]")} ${message.author.username} - ${message.content ? message.content : "arquivo"}`)
      message.author.send("to off ja respondo :)")
    }
  }
})

function askQuestion(query) {
  const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
  });

  return new Promise(async resolve => rl.question(query, ans => {
      if(commands[ans]){
        commands[ans]()
      }else{
        console.log(`Comando ${colors.cyan(ans)} não encontrado!`)
      }
      rl.close()
      askQuestion(query)
  }))  
}

 
client.login(config.token);